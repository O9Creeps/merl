# merl
An open-source useless python library. Developed using the code.org IDE, because why not.

If 'pip install merl' doesn't work, then gimmie some time i gotta figure it out.

## Functions
### printanim(msg)
Prints 'msg' where 'msg' is a string. If 'msg' does not have spaces, then it all prints at once. Else, it prints word-by-word.

### replyPrint(prompt)
Where 'prompt' is a string. This has Merl reply whatever, based on what you put in. Expect "I don't know." to show up more than once. With the exception of your system's time being between 9 AM and 4 PM, of course, because then you get a high traffic message more than half the time!
