from setuptools import setup

setup(
    name='merl',
    version='0.1.0',    
    description='A useless python lybrary',
    url='https://github.com/O9Creeps/merl',
    author='O9CreeperBoi',
    author_email='not provided',    
    license='MIT',
    packages=['merl'],
    install_requires=[],

    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: Freeware',  
        'Operating System :: OS Independent',        
        'Programming Language :: Python :: 3'
    ],
)    
